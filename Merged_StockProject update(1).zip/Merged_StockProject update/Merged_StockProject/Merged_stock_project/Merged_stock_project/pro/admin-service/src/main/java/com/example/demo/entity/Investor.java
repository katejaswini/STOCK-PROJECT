package com.example.demo.entity;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "investors")
public class Investor {

    @Id
    private Long id;

    private String name;
    private String email;
    private String phone;
    private Long balance;
}