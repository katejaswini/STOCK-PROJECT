package com.authservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.authservice.config.FeignClientConfig;
import com.authservice.dto.BuyRequestDTO;
import com.authservice.dto.InvestorDto;
import com.authservice.dto.RegisterRequest;

import feign.Request;
import jakarta.validation.Valid;

@FeignClient(name = "investor-service", url = "http://localhost:8085",configuration = FeignClientConfig.class)
public interface InvestorClient {
	
	@PostMapping("/api/investor/add")
	public String addInvestor(@RequestBody InvestorDto dto);
}
