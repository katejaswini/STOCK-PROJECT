package com.example.demo.entity;

public enum RoleType {
    INVESTOR,
    ADVISOR,
    ADMIN
}
