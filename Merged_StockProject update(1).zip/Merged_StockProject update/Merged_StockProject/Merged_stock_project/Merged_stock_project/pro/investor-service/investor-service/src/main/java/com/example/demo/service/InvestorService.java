package com.example.demo.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.client.AdminClient;
import com.example.demo.client.AdvisorClient;
import com.example.demo.client.NotificationClient;
import com.example.demo.dto.AdvisorDTO;
import com.example.demo.dto.BuyRequestDTO;
import com.example.demo.dto.CompanyDTO;
import com.example.demo.dto.SellRequestDTO;
import com.example.demo.dto.StockDTO;
import com.example.demo.dto.TransferRequestDTO;
import com.example.demo.dto.UpdateQuantity;
import com.example.demo.entity.AllocatedAdvisorTable;
import com.example.demo.entity.Holding;
import com.example.demo.entity.Investor;
import com.example.demo.entity.Transaction;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.AllocationRepo;
import com.example.demo.repository.HoldingRepository;
import com.example.demo.repository.InvestorRepository;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.dto.NotificationRequest;
import com.example.demo.dto.RequestAdvisorDto;
import com.example.demo.dto.RequestAdvisorDto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InvestorService {

	private final InvestorRepository repo;
	private final TransactionRepository tRepo;
	private final HoldingRepository hRepo;
	private final NotificationClient notificationClient;
	private final AdvisorClient advisorClient;
	private final AdminClient adminClient;
	private final AllocationRepo allocationRepo;

	@Transactional
	public String buyStock(BuyRequestDTO dto) {

		// 1️⃣ Get Investor
		Investor investor = repo.findById(dto.getInvestorId())
				.orElseThrow(() -> new ResourceNotFoundException("Investor not found"));

		// 2️⃣ Fetch Latest Price from Admin Service
		StockDTO stock = adminClient.getStock(dto.getSymbol());

		if (stock == null) {
			throw new ResourceNotFoundException("Stock not found");
		}

		BigDecimal currentPrice = stock.getCurrentPrice();

		// 3️⃣ Calculate Total
		BigDecimal total = currentPrice.multiply(
				BigDecimal.valueOf(dto.getQuantity()));

		// 4️⃣ Check Balance
		if (investor.getBalance().compareTo(total) < 0) {
			return "Insufficient Balance";
		}

		// 5️⃣ Deduct Balance
		investor.setBalance(
				investor.getBalance().subtract(total));
		repo.save(investor);

		// 6️⃣ Reduce Stock Quantity in Admin Service
		UpdateQuantity update = new UpdateQuantity();
		update.setSymbol(dto.getSymbol());
		update.setQuantity(dto.getQuantity());

		adminClient.updateQuantityBuy(update);

		/* HOLDING SAVE */

		Holding h = hRepo.findByInvestorIdAndAssetName(
				dto.getInvestorId(),
				dto.getSymbol());

		if (h == null) {

			h = new Holding();
			h.setInvestorId(dto.getInvestorId());
			h.setAssetName(dto.getSymbol());
			h.setQuantity(dto.getQuantity());

		} else {

			h.setQuantity(h.getQuantity() + dto.getQuantity());
		}

		hRepo.save(h);

		/* TRANSACTION */

		Transaction t = new Transaction();
		t.setInvestorId(dto.getInvestorId());
		t.setType("BUY");
		t.setAssetName(dto.getSymbol());
		t.setQuantity(dto.getQuantity());
		t.setPrice(currentPrice);
		t.setDate(LocalDate.now().toString());

		tRepo.save(t);

		/* EMAIL NOTIFICATION */

		String message = String.format("""
				Subject: Transaction Confirmation: %s

				Dear %s,

				This is to confirm that your request to Buy has been successfully processed.
				Please find the details of your transaction below:

				Stock Asset: %s
				Execution Price: $%.2f
				Quantity: %d
				Total Value: $%.2f
				Remaining Balance: $%.2f

				Thank you for choosing our platform for your investment needs.
				""",
				dto.getSymbol(),
				investor.getInvestorName(),
				dto.getSymbol(),
				currentPrice.doubleValue(),
				dto.getQuantity(),
				total.doubleValue(),
				investor.getBalance().doubleValue());

		NotificationRequest request = new NotificationRequest();
		request.setEmail(investor.getEmail());
		request.setMessage(message);

		notificationClient.sendNotification(request);

		return "Stock Bought Successfully";
	}

	public String sellStock(SellRequestDTO dto) {

		// 1️⃣ Get Investor
		Investor investor = repo.findById(dto.getInvestorId())
				.orElseThrow(() -> new ResourceNotFoundException("Investor not found"));

		// 2️⃣ Get Holding
		Holding h = hRepo.findByInvestorIdAndAssetName(
				dto.getInvestorId(),
				dto.getAssetName());

		if (h == null) {
			return "Stock not found";
		}

		if (h.getQuantity() < dto.getQuantity()) {
			return "Not enough stock";
		}

		// 3️⃣ Fetch Latest Price from Admin Service
		StockDTO stock = adminClient.getStock(dto.getAssetName());

		if (stock == null) {
			throw new ResourceNotFoundException("Stock not found in Admin");
		}

		BigDecimal currentPrice = stock.getCurrentPrice();

		// 4️⃣ Calculate Total
		BigDecimal total = currentPrice.multiply(
				BigDecimal.valueOf(dto.getQuantity()));

		/* 5️⃣ UPDATE BALANCE */

		investor.setBalance(
				investor.getBalance().add(total));
		repo.save(investor);

		/* 6️⃣ REDUCE HOLDING */

		h.setQuantity(h.getQuantity() - dto.getQuantity());

		if (h.getQuantity() == 0) {
			hRepo.delete(h);
		} else {
			hRepo.save(h);
		}

		/* 7️⃣ INCREASE STOCK QUANTITY BACK IN ADMIN */

		UpdateQuantity update = new UpdateQuantity();
		update.setSymbol(dto.getAssetName());
		update.setQuantity(dto.getQuantity());

		adminClient.updateQuantitySell(update);

		/* 8️⃣ SAVE TRANSACTION */

		Transaction t = new Transaction();
		t.setInvestorId(dto.getInvestorId());
		t.setType("SELL");
		t.setAssetName(dto.getAssetName());
		t.setQuantity(dto.getQuantity());
		t.setPrice(currentPrice);
		t.setDate(LocalDate.now().toString());

		tRepo.save(t);

		/* EMAIL NOTIFICATION */

		String message = String.format("""
				Subject: Transaction Confirmation: %s

				Dear %s,

				This is to confirm that your request to Sell has been successfully processed.
				Please find the details of your transaction below:

				Stock Asset: %s
				Execution Price: $%.2f
				Quantity: %d
				Total Value: $%.2f
				Updated Balance: $%.2f

				Transaction Type: SELL
				Transaction Date: %s

				Thank you for choosing our platform for your investment needs.
				""",
				dto.getAssetName(),
				investor.getInvestorName(),
				dto.getAssetName(),
				currentPrice.doubleValue(),
				dto.getQuantity(),
				total.doubleValue(),
				investor.getBalance().doubleValue(),
				t.getDate());

		NotificationRequest request = new NotificationRequest();
		request.setEmail(investor.getEmail());
		request.setMessage(message);

		notificationClient.sendNotification(request);

		return "Stock Sold Successfully";
	}

	@Transactional
	public String transferMoney(TransferRequestDTO dto) {

		// 1️⃣ Get Investors
		Investor fromInvestor = repo.findById(dto.getFromInvestorId())
				.orElseThrow(() -> new ResourceNotFoundException("Sender not found"));

		Investor toInvestor = repo.findById(dto.getToInvestorId())
				.orElseThrow(() -> new ResourceNotFoundException("Receiver not found"));

		// 2️⃣ Convert amount to BigDecimal
		BigDecimal amount = BigDecimal.valueOf(dto.getAmount());

		// 3️⃣ Check Balance
		if (fromInvestor.getBalance().compareTo(amount) < 0) {
			return "Insufficient Balance";
		}

		String date = LocalDate.now().toString();

		/* 4️⃣ DEDUCT FROM SENDER */
		fromInvestor.setBalance(
				fromInvestor.getBalance().subtract(amount));

		/* 5️⃣ ADD TO RECEIVER */
		toInvestor.setBalance(
				toInvestor.getBalance().add(amount));

		repo.save(fromInvestor);
		repo.save(toInvestor);

		/* 6️⃣ SAVE TRANSACTION RECORDS */

		Transaction senderTransaction = new Transaction();
		senderTransaction.setInvestorId(fromInvestor.getInvestorId());
		senderTransaction.setType("TRANSFER_DEBIT");
		senderTransaction.setAssetName("Fund Transfer");
		senderTransaction.setQuantity(0);
		senderTransaction.setPrice(amount);
		senderTransaction.setDate(date);

		tRepo.save(senderTransaction);

		Transaction receiverTransaction = new Transaction();
		receiverTransaction.setInvestorId(toInvestor.getInvestorId());
		receiverTransaction.setType("TRANSFER_CREDIT");
		receiverTransaction.setAssetName("Fund Transfer");
		receiverTransaction.setQuantity(0);
		receiverTransaction.setPrice(amount);
		receiverTransaction.setDate(date);

		tRepo.save(receiverTransaction);

		/* EMAIL TO SENDER */

		String senderMessage = String.format("""
				Subject: Transaction Confirmation: Fund Transfer

				Dear %s,

				This is to confirm that your request to Transfer has been successfully processed.
				Please find the details of your transaction below:

				Transfer Amount: $%.2f
				Transferred To: %s
				Remaining Balance: $%.2f

				Transaction Type: TRANSFER
				Transaction Date: %s

				Thank you for choosing our platform for your investment needs.
				""",
				fromInvestor.getInvestorName(),
				amount.doubleValue(),
				toInvestor.getInvestorName(),
				fromInvestor.getBalance().doubleValue(),
				date);

		NotificationRequest senderRequest = new NotificationRequest();
		senderRequest.setEmail(fromInvestor.getEmail());
		senderRequest.setMessage(senderMessage);

		notificationClient.sendNotification(senderRequest);

		/* EMAIL TO RECEIVER */

		String receiverMessage = String.format("""
				Subject: Transaction Confirmation: Funds Received

				Dear %s,

				You have successfully received funds.
				Please find the details below:

				Received Amount: $%.2f
				Received From: %s
				Updated Balance: $%.2f

				Transaction Type: TRANSFER
				Transaction Date: %s

				Thank you for choosing our platform for your investment needs.
				""",
				toInvestor.getInvestorName(),
				amount.doubleValue(),
				fromInvestor.getInvestorName(),
				toInvestor.getBalance().doubleValue(),
				date);

		NotificationRequest receiverRequest = new NotificationRequest();
		receiverRequest.setEmail(toInvestor.getEmail());
		receiverRequest.setMessage(receiverMessage);

		notificationClient.sendNotification(receiverRequest);

		return "Transfer Successful";
	}

	public List<AdvisorDTO> getAdvisorList() {
		return advisorClient.getAdvisors();
	}

	public List<Transaction> history(Long id) {
		return tRepo.findByInvestorId(id);
	}

	public List<Holding> getHolding(Long id) {
		return hRepo.findByInvestorId(id);
	}

	public String getAdvice(String question) {
		return advisorClient.getAdvice(question);
	}

	public List<CompanyDTO> getCompanyList() {
		return adminClient.getAllCompanies();
	}

	public List<StockDTO> getStockList() {
		return adminClient.getAllStocks();
	}
	public String allocateAdvisor(RequestAdvisorDto requestAdvisor) {
		AllocatedAdvisorTable alloc = new AllocatedAdvisorTable();
		alloc.setInvestorId(requestAdvisor.getInvestorId());
		alloc.setAdvisorId(requestAdvisor.getAdvisorId());
		allocationRepo.save(alloc);
		advisorClient.allocateAdvisor(requestAdvisor);
		return "Advisor Allocated ";
	}

	public Investor addInvestor(Investor investor) {
		return repo.save(investor);
	}
}