package com.portfolioservice.controller;

import com.portfolioservice.dto.*;
import com.portfolioservice.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/portfolios")
@RequiredArgsConstructor
public class PortfolioController {

    private final PortfolioService portfolioService;
    private final HoldingService holdingService;
    private final PerformanceService performanceService;
    private final TransferService transferService;

    //Create a new portfolio for the authenticated investor
    @PostMapping
    public ResponseEntity<ApiResponse<PortfolioResponse>> createPortfolio(
            @Valid @RequestBody CreatePortfolioRequest request,
            Authentication authentication) {

       Long investorId = getInvestorId(authentication);
//        Long investorId = 1L;   // temporary testing
        
        PortfolioResponse response = portfolioService.createPortfolio(investorId, request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Portfolio created successfully", response));
    }

    //Get all portfolios belonging to the authenticated investor.

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<PortfolioResponse>>> getMyPortfolios(
            Authentication authentication) {

        Long investorId = getInvestorId(authentication);
    	
        //Long investorId = 1L; // temp testing
        List<PortfolioResponse> portfolios = portfolioService.findByInvestorId(investorId);
        return ResponseEntity.ok(ApiResponse.ok("Portfolios retrieved", portfolios));
    }

    //Get a specific portfolio by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PortfolioResponse>> getPortfolioById(
            @PathVariable Long id) {

        PortfolioResponse response = portfolioService.findById(id);
        return ResponseEntity.ok(ApiResponse.ok("Portfolio retrieved", response));
    }

    //Get all holdings for a portfolio
    @GetMapping("/{id}/holdings")
    public ResponseEntity<ApiResponse<List<HoldingResponse>>> getHoldings(
            @PathVariable Long id) {

        List<HoldingResponse> holdings = holdingService.getHoldingsForPortfolio(id);
        return ResponseEntity.ok(ApiResponse.ok("Holdings retrieved", holdings));
    }

    //Get performance analytics (P&L) for a portfolio
    @GetMapping("/{id}/performance")
    public ResponseEntity<ApiResponse<PerformanceResponse>> getPerformance(
            @PathVariable Long id) {

        PerformanceResponse perf = performanceService.getPerformance(id);
        return ResponseEntity.ok(ApiResponse.ok("Performance analytics retrieved", perf));
    }

    //Get asset allocation breakdown for a portfolio
    @GetMapping("/{id}/allocation")
    public ResponseEntity<ApiResponse<List<HoldingResponse>>> getAllocation(
            @PathVariable Long id) {

        List<HoldingResponse> holdings = holdingService.getHoldingsForPortfolio(id);
        return ResponseEntity.ok(ApiResponse.ok("Asset allocation retrieved", holdings));
    }

    //Transfer funds between two portfolios owned by the authenticated invest
    @PostMapping("/transfer")
    public ResponseEntity<ApiResponse<Void>> transferFunds(
            @Valid @RequestBody TransferRequest request,
            Authentication authentication) {

       Long investorId = getInvestorId(authentication);
        //Long investorId = 1L;
        transferService.transferFunds(investorId, request);
        return ResponseEntity.ok(ApiResponse.ok("Transfer completed successfully", null));
    }


    //Extract investor ID from JWT authentication principal
    private Long getInvestorId(Authentication authentication) {
        Object principal = authentication.getPrincipal();
        if (principal instanceof Long) {
            return (Long) principal;
        }
        // Fallback: try parsing the string principal
        return Long.parseLong(principal.toString());
    }
}
